export class CreateSocketioDto {}
